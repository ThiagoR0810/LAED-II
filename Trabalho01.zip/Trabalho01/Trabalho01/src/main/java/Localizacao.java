
public class Localizacao {
    // cursor para pegar posicao da palavra no texto
    public static int linha;
    public static int coluna; // cada palavra fica em uma coluna
}